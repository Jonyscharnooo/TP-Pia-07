import express from "express";
import "dotenv/config";
import Preguntas from "./models/preguntas.js";
import Respuestas from "./models/respuestas.js";
import PreguntasService from "./services/preguntasService.js";
import RespuestasService from "./services/respuestasService.js";

const port = 3000
const app = express();
app.use(express.json())

/*
http://localhost:3000/

{
    "Pregunta": "¿Cual es mi nombre?",
    "Opcion_1": "Julian",
    "Opcion_2": "Gonzalo",
    "Opcion_3": "Jonathan",
    "Opcion_4": "Gaston",
    "Respuesta_Correcta": 3
}

{
    "User_Id": 1,
    "Respuesta_Seleccionada": 3,
    "fk_Id_Pregunta": 1
}
*/

app.post('/preguntas', async (req, res) => {
    const pregunta = await new PreguntasService().Create(req.body);
      return res.status(200).json(pregunta);
  });
app.put('/preguntas/:id', async (req, res) => {
    const id = req.params.id;
    const pregunta = new Preguntas();
    pregunta.Pregunta = req.body.Pregunta;
    pregunta.Opcion_1 = req.body.Opcion_1;
    pregunta.Opcion_2 = req.body.Opcion_2;
    pregunta.Opcion_3 = req.body.Opcion_3;
    pregunta.Opcion_4 = req.body.Opcion_4;
    pregunta.Respuesta_Correcta = req.body.Respuesta_Correcta;
    await new PreguntasService().Update(pregunta, id);
      return res.status(200).json(pregunta);
});
app.delete('/preguntas/:id', async (req, res) => {
    const id = req.params.id;
    const pregunta = await new PreguntasService().Delete(id);
      return res.status(200).json(pregunta);
});
app.get('/preguntas/azar', async (req, res) => {
    const pregunta = await new PreguntasService().GetAzar();
      return res.status(200).json(pregunta);
});
app.get('/preguntas', async (req, res) => {
    const pregunta = await new PreguntasService().Get();
      return res.status(200).json(pregunta);
});
app.post('/respuestas', async (req, res) => {
    const respuesta = await new RespuestasService().Create(req.body);
      return res.status(200).json(respuesta);
  });

app.listen(port, () => {
    console.log(`Se esta usando el puerto: ${port}`)
});