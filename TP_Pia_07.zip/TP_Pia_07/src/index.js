import express from "express";
import "dotenv/config";
import Preguntas from "./models/preguntas.js";
import Respuestas from "./models/respuestas.js";
import PreguntasService from "./services/preguntasService.js";

const port = 3000
const app = express();
app.use(express.json())

/*
http://localhost:3000/

{
    "pregunta": "¿Cual es mi nombre?",
    "opcion_1": "Julian",
    "opcion_2": "Gonzalo",
    "opcion_3": "Jonathan",
    "opcion_4": "Gaston",
    "respuesta_correcta": 3
}
*/

app.post('/preguntas', async (req, res)=> {
    const pregunta = await new PreguntasService().Create(req.body);
      return res.status(200).json(pregunta)
  });

  app.listen(port, () => {
    console.log(`Se esta usando el puerto: ${port}`)
});