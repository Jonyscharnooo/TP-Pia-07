class Preguntas {
    pregunta;
    opcion_1;
    opcion_2;
    opcion_3;
    opcion_4;
    respuesta_correcta;
    fecha_de_creacion;
}

export default Preguntas;