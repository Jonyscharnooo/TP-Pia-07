class Respuestas {
    user_id;
    respuesta_seleccionada;
    es_respuesta_correcta;
    fecha_de_creacion;
}

export default Respuestas;