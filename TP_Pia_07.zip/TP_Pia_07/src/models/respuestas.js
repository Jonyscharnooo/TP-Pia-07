class Respuestas {
    user_id;
    respuesta_seleccionada;
    es_respuesta_correcta;
    fecha_de_creacion;
    fk_id_pregunta;
}

export default Respuestas;