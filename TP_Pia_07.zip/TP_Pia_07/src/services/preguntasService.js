import sql from 'mssql'
import config from "../dbconfig.js";

/*
class Preguntas {
    id_pregunta;
    pregunta;
    opcion_1;
    opcion_2;
    opcion_3;
    opcion_4;
    respuesta_correcta;
    fecha_de_creacion;
}
*/

export default class PreguntasService {
    Create = async (pregunta) => {
        const fechaActual = new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '');
        const connection = await sql.connect(config);
        const results = await connection.request()
        .input("pPregunta", sql.VarChar, pregunta.Pregunta)
        .input("pOpcion_1", sql.VarChar, pregunta.Opcion_1)
        .input("pOpcion_2", sql.VarChar, pregunta.Opcion_2)
        .input("pOpcion_3", sql.VarChar, pregunta.Opcion_3)
        .input("pOpcion_4", sql.VarChar, pregunta.Opcion_4)
        .input("pRespuesta_Correcta", sql.Int, pregunta.Respuesta_Correcta)
        .input("pFecha_De_Creacion", sql.VarChar, fechaActual)
        .query('INSERT INTO Preguntas (Pregunta, Opcion_1, Opcion_2, Opcion_3, Opcion_4, Respuesta_Correcta, Fecha_De_Creacion) VALUES (@pPregunta, @pOpcion_1, @pOpcion_2, @pOpcion_3, @pOpcion_4, @pRespuesta_Correcta, @pFecha_De_Creacion)');
        console.log(results);
        return results;
      };

    Update = async (pregunta, id) => {
        const fechaActual = new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '');
        const connection = await sql.connect(config);
        const results = await connection.request()
        .input("pId", sql.Int, id)
        .input("pPregunta", sql.VarChar, pregunta.Pregunta)
        .input("pOpcion_1", sql.VarChar, pregunta.Opcion_1)
        .input("pOpcion_2", sql.VarChar, pregunta.Opcion_2)
        .input("pOpcion_3", sql.VarChar, pregunta.Opcion_3)
        .input("pOpcion_4", sql.VarChar, pregunta.Opcion_4)
        .input("pRespuesta_Correcta", sql.Int, pregunta.Respuesta_Correcta)
        .input("pFecha_De_Creacion", sql.VarChar, fechaActual)
        .query('UPDATE Preguntas SET Pregunta = @pPregunta, Opcion_1 = @pOpcion_1, Opcion_2 = @pOpcion_2, Opcion_3 = @pOpcion_3, Opcion_4 = @pOpcion_4, Respuesta_Correcta  = @pRespuesta_Correcta, Fecha_De_Creacion  = @pFecha_De_Creacion WHERE Id_Pregunta = @pId');
        console.log(results);
        return results;
      };

    Delete = async (id) => {
        const connection = await sql.connect(config)
        const results = await connection.request()
        .input('pId', sql.Int, id)
        .query('DELETE FROM Preguntas WHERE Id_Pregunta = @pId');
        console.log(results);
        return results;
    };
    GetAzar = async () => {
      const connection = await sql.connect(config)
      const results = await connection.request()
      .query('SELECT * FROM Preguntas ORDER BY NewId()');
      console.log(results);
      return results;
  };
    Get = async () => {
        const connection = await sql.connect(config)
        const results = await connection.request()
        .query('SELECT * FROM Preguntas');
        console.log(results);
        return results;
    };
}