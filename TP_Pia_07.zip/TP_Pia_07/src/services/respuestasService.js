import sql from 'mssql'
import config from "../dbconfig.js";

/*
class Respuestas {
    user_id;
    respuesta_seleccionada;
    es_respuesta_correcta;
    fecha_de_creacion;
    fk_id_pregunta;
}
*/

export default class RespuestasService {
    Create = async (respuesta) => {
        if (respuesta.User_Id < 0) {
          throw new Error('El User_Id no puede ser negativo');
        }
        const fechaActual = new Date();
        const connection = await sql.connect(config);
        const preg = await connection.request()
        .input("pId_Pregunta", sql.Int, respuesta.fk_Id_Pregunta)
        .query('SELECT Respuesta_Correcta FROM Preguntas WHERE Id_Pregunta = @pId_Pregunta');
        const esRespuestaCorrecta = (respuesta.Respuesta_Seleccionada === preg.recordset[0].Respuesta_Correcta);
        const results = await connection.request()
        .input("pUser_Id", sql.Int, respuesta.User_Id)
        .input("pRespuesta_Seleccionada", sql.Int, respuesta.Respuesta_Seleccionada)
        .input("pEs_Respuesta_Correcta", sql.Bit, esRespuestaCorrecta)
        .input("pFecha_De_Creacion", sql.DateTime, fechaActual)
        .input("pfk_Id_Pregunta", sql.Int, respuesta.fk_Id_Pregunta)
        .query('INSERT INTO Respuestas (User_Id, Respuesta_Seleccionada, Fecha_De_Creacion, Es_Respuesta_Correcta, fk_Id_Pregunta) VALUES (@pUser_Id, @pRespuesta_Seleccionada, @pFecha_De_Creacion, @pEs_Respuesta_Correcta, @pfk_Id_Pregunta)');
        return results;
      };
    }